from nickgenfast import generate_nick_name

