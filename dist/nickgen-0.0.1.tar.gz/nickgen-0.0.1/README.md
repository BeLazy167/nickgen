# Random Name Generator

This Python package generates random names by combining adjectives, verbs, and nouns from predefined word lists.

## Installation

To install this package, you can use pip:

## Usage

Here's an example of how to use the package:

```python
from nickgen import generate_nick_name

# Generate a random name
random_name = generate_nick_name()
print(random_name)
```
